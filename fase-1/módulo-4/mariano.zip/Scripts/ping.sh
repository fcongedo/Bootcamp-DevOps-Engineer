#!/bin/bash
ping www.google.com.ar
