#!/bin/bash
mount -a
